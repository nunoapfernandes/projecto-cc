package pdu_data;


public class TypeNotFoundException extends Throwable{
    public TypeNotFoundException(){
        super();
    }

    public TypeNotFoundException(String s){
        super(s);
    }

}
